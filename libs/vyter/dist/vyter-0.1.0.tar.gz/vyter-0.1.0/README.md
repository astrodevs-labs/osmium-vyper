
### Architecture

#### Factory
- create rule from json
- create default rule

#### Rule
- Object containing logic
- Takes a source files/all source files, ast
- Returns an array of diagnostics

